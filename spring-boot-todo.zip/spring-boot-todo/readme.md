# Full stack Vaadin and Spring Boot demo app

![Vaadin and Spring Boot example with JPA and H2](screenshot.png)

## Running

You can run the project with 

```
mvn package spring-boot:run
```