package com.example;

/**
 * Created by mhellber on 9/1/16.
 */
public interface TodoChangeListener {
    void todoChanged(Todo todo);
}
