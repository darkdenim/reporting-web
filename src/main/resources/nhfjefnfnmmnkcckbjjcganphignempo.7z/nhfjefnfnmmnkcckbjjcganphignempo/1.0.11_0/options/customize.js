chrome.extension.onRequest.addListener(function(request) {
  if (request.command != "filters_updated")
    return;
  BGcall("get_custom_filters_text", function(text) {
    console.log(text);
    refreshFilters(text);
  });
});

$(function() {
    BGcall("get_custom_filters_text", function(text) {
        refreshFilters(text);
    });
  
    renderStats();
    
    $('#close').click(function(e) {
        e.preventDefault();
        closeSettings();
    });
    
    $('#stats_check').bind('change', function() {
        setStats();
    });
});

function closeSettings()
{
    window.close();
}

function removeFilter(index)
{
    BGcall("get_custom_filters_text", function(text) {
        var filters = $.trim(text).split("\n");
        var active = [];
        $.each(filters, function(i) {
            var filter = filters[i];
            if (i != index &&
                $.trim(filter) != '')
            {
                active.push(filter);
            }
        });
        activeFilters = active.join('\n');
        BGcall("set_custom_filters_text", activeFilters);
        refreshFilters(activeFilters);
    });
}

function refreshFilters(text)
{
    $('#blockedlist,#allowedlist').html('');

    var filters = $.trim(text).split("\n");
    var i18n_delete = chrome.i18n.getMessage("removelabel");
    var items = [[],[]];
    var pattern = /^@@\|\|/;
    var filter, element, i, index;
    
    $.each(filters, function(i) {
        filter = filters[i];
        
        if ($.trim(filter) == "")
        {
            return;
        }
        
        element = '<li><input type="button" value="' + i18n_delete + '" data-index="' + i + '" /> ' + filter.replace(pattern, '') + '</li>';

        index = pattern.test(filter) == true ? 1 : 0;
        items[index].push(element);
    });

    var selector = ['blockedlist', 'allowedlist'];
    
    for (i in selector)
    {
        if (items[i].length > 0)
        {        
            $('#' + selector[i]).append('<ul>' + items[i].join('') + '</ul>');
        }
        else
        {
            $('#' + selector[i]).append('<p>' + chrome.i18n.getMessage(selector[i] + '_empty') + '</p>');
        }
    }
    
    $('#blockedlist input[type="button"], #allowedlist input[type="button"]').click(function(e) {
        e.preventDefault();
        removeFilter($(this).attr('data-index'));
    });    
}
  
    function getPref(name){
        var value = storage_get(name);
        if(value == 'false') 
            return false; 
        else  
            return value;
    }
    function setPref(name,value){
        storage_set(name, value);
    }
  
    function setStats(){
      if(getPref('stats')){
          setPref('stats',false);
          document.getElementById('stats_check').removeAttribute('checked');
      }else{
          setPref('stats',true);
          document.getElementById('stats_check').setAttribute('checked');
      }
      renderStats();
    }
    function renderStats(){
      if(getPref('stats')){
        document.getElementById('stats_check').setAttribute('checked','checked');
      }
    }
    