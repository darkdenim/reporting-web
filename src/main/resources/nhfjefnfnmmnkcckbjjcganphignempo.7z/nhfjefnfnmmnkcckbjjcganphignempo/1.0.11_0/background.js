  // OPTIONAL SETTINGS

  function Settings() {
    var defaults = {
      debug_logging: false,
      show_google_search_text_ads: false,
      show_context_menu_items: true,
      show_advanced_options: false,
      use_webrequest_blocking: false,
    };
    // Opt in Chrome 17 users to webRequest.
    if (chrome.webRequest)
      defaults.use_webrequest_blocking = true;
    var settings = storage_get('settings') || {};
    this._data = $.extend(defaults, settings);
  };
  Settings.prototype = {
    set: function(name, is_enabled) {
      this._data[name] = is_enabled;
      // Don't store defaults that the user hasn't modified
      var stored_data = storage_get("settings") || {};
      stored_data[name] = is_enabled;
      storage_set('settings', stored_data);
    },
    get_all: function() {
      return this._data;
    }
  };
  _settings = new Settings();

  // Open a new tab with a given URL.
  // Inputs:
  //   url: string - url for the tab
  //   nearActive: bool - open the tab near currently active (instead of at the end). optional, defaults to false
  //   safariWindow (Safari only): window object - window where the tab will be created. optional, defaults
  //     to active window. Because Safari supports clickthrough on extension elements, Safari code will almost
  //    always need to pass this argument. Chrome doesn't support it, so leave this argument empty in Chrome code.
  function openTab(url, nearActive, safariWindow) {
    if (!SAFARI) {
      if (!nearActive) {
        chrome.tabs.create({url: url});
      } else {
        chrome.windows.getCurrent(function(currentWindow) {
          chrome.tabs.query({active: true, windowId: currentWindow.id}, function(tabs) {
            chrome.tabs.create({ url: url, index: (tabs[0] ? tabs[0].index + 1 : undefined) });
          });
        });
      }
    } else {
      safariWindow = safariWindow || safari.application.activeBrowserWindow;
      var index = undefined;
      if (nearActive && safariWindow && safariWindow.activeTab) {
        for (var i = 0; i < safariWindow.tabs.length; i++) {
          if (safariWindow.tabs[i] === safariWindow.activeTab) {
            index = i + 1;
            break;
          }
        }
      }
      var tab;
      if (safariWindow) {
        tab = safariWindow.openTab("foreground", index); // index may be undefined
        if (!safariWindow.visible) {
          safariWindow.activate();
        }
      } else {
        tab = safari.application.openBrowserWindow().tabs[0];
      }
      var relative = (!/:\/\//.test(url)); // fix relative URLs
      tab.url = (relative ? chrome.extension.getURL(url) : url);
    }
  };
  
  
function openTabOnce(tabUrl)
{
    if (!SAFARI)
    {
        chrome.tabs.query({windowId: chrome.windows.WINDOW_ID_CURRENT},function(tab){
            var openTab = null;
            $.each(tab, function(i) {
                if (tab[i].url == tabUrl)
                {
                    openTab = tab[i];
                }
            });
            
            if (openTab == null)
            {
                chrome.tabs.create({url: tabUrl});
            }
            else if (openTab.active == false)
            {
                chrome.tabs.update(openTab.id, {active: true});
            }
        });
    }
    else
    {
        var openTab = null;
        
        safariWindow = safariWindow || safari.application.activeBrowserWindow;
        if (safariWindow && safariWindow.activeTab)
        {
            openTab = safariWindow.activeTab;
        }
        
        var tab;
        if (safariWindow)
        {
            if (openTab == null)
            {
                tab = safariWindow.openTab("foreground");
                if (!safariWindow.visible)
                {
                    safariWindow.activate();
                }
            }
            else
            {
                tab = openTab;
            }
        }
        else
        {
            tab = safari.application.openBrowserWindow().tabs[0];
        }
        
        tab.url = tabUrl;        
    }
};

  GLOBAL_block_style = "old";
  // Implement blocking via the Chrome webRequest API.
  (function() {
    if (SAFARI)
      return;

    // Stores url, whitelisting, and blocking info for a tabid+frameid
    // TODO: can we avoid making this a global once 'old' style dies?
    frameData = {
      // Return the data object for |tabId| and |frameId|, or
      // undefined if |tabId| and |frameId| are not being tracked.
      get: function(tabId, frameId) {
        return (frameData[tabId] || {})[frameId];
      },

      // Record that |tabId|, |frameId| points to |url|.
      record: function(tabId, frameId, url) {
        var fd = frameData;
        if (!fd[tabId]) fd[tabId] = {};
        fd[tabId][frameId] = {
          url: url,
          // Cache these as they'll be needed once per request
          domain: parseUri(url).hostname
        };
        if (frameId === 0) {
          fd[tabId][frameId].whitelisted = page_is_whitelisted(url);
          fd[tabId][frameId].resources = {};
        }
      },

      // Watch for requests for new tabs and frames, and track their URLs.
      // Inputs: details: object from onBeforeRequest callback
      // Returns false if this request's tab+frame are not trackable.
      track: function(details) {
        var fd = frameData, tabId = details.tabId;

        if (tabId == -1) // A hosted app's background page
          return false;

        if (details.type == 'main_frame') { // New tab
          delete fd[tabId];
          fd.record(tabId, 0, details.url);
          log("\n-------", fd.get(tabId, 0).domain, ": loaded in tab", tabId, "--------\n\n");
          return true;
        }

        // Request from a tab opened before Adblock started, or from a
        // chrome:// tab containing an http:// iframe
        if (!fd[tabId]) {
          log("[DEBUG]", "Ignoring unknown tab:", tabId, details.frameId, details.url);
          return false;
        }

        // Some times e.g. Youtube create empty iframes via JavaScript and
        // inject code into them.  So requests appear from unknown frames.
        // Treat these frames as having the same URL as the tab.
        var potentialEmptyFrameId = (details.type == 'sub_frame' ? details.parentFrameId: details.frameId);
        if (undefined === fd.get(tabId, potentialEmptyFrameId)) {
          fd.record(tabId, potentialEmptyFrameId, fd.get(tabId, 0).url);
          log("[DEBUG]", "Null frame", tabId, potentialEmptyFrameId, "found; giving it the tab's URL.");
        }

        if (details.type == 'sub_frame') { // New frame
          fd.record(tabId, details.frameId, details.url);
          log("[DEBUG]", "=========== Tracking frame", tabId, details.parentFrameId, details.frameId, details.url);
        }

        return true;
      },

      // Record a resource for the resource blocker.
      storeResource: function(tabId, url, elType) {
        if (!get_settings().show_advanced_options)
          return;
        var data = frameData.get(tabId, 0);
        if (data !== undefined)
          data.resources[elType + ':|:' + url] = null;
      },

      // When a tab is closed, delete all its data
      onTabClosedHandler: function(tabId) {
        log("[DEBUG]", "----------- Closing tab", tabId);
        delete frameData[tabId];
      }
    };

    // When a request starts, perhaps block it.
    function onBeforeRequestHandler(details) {
      try {
        if (sessionStorage.adblock_is_paused)
          return { cancel: false };

        if (!frameData.track(details))
          return { cancel: false };

        var tabId = details.tabId;
        var elType = ElementTypes.fromOnBeforeRequestType(details.type);

        frameData.storeResource(tabId, details.url, elType);

        if (frameData.get(tabId, 0).whitelisted) {
          log("[DEBUG]", "Ignoring whitelisted tab", tabId, details.url.substring(0, 100));
          return { cancel: false };
        }

        // For most requests, Chrome and we agree on who sent the request: the frame.
        // But for iframe loads, we consider the request to be sent by the outer
        // frame, while Chrome claims it's sent by the new iframe.  Adjust accordingly.
        var requestingFrameId = (details.type == 'sub_frame' ? details.parentFrameId : details.frameId);
        // May the URL be loaded by the requesting frame?
        var frameDomain = frameData.get(tabId, requestingFrameId).domain;
        var blocked = _myfilters.blocking.matches(details.url, elType, frameDomain);

        var canPurge = (elType & (ElementTypes.image | ElementTypes.subdocument | ElementTypes.object));
        if (canPurge && blocked) {
          // frameUrl is used by the recipient to determine whether they're the frame who should
          // receive this or not.  Because the #anchor of a page can change without navigating
          // the frame, ignore the anchor when matching.
          var frameUrl = frameData.get(tabId, requestingFrameId).url.replace(/#.*$/, "");
          var data = { command: "purge-elements", frameUrl: frameUrl, url:details.url, elType: elType };
          chrome.tabs.sendRequest(tabId, data); 
        }

        log("[DEBUG]", "Block result", blocked, details.type, frameDomain, details.url.substring(0, 100));
        return { cancel: blocked };
      }
      catch(ex) {
        logNewStyleBlockingError(ex.stack);
        return { cancel: false };
      }
    }

    // Upon error in webRequest API, gracefully degrade to old style
    // Inputs: message: the message explaining the abort
    endNewStyleBlocking = function() {
      GLOBAL_block_style = "old";
      _settings.set('use_webrequest_blocking', false);
      try {
        chrome.webRequest.onBeforeRequest.removeListener(onBeforeRequestHandler);
// issue 6446
//        chrome.webNavigation.onCreatedNavigationTarget.removeListener(onCreatedNavigationTargetHandler);
      }
      catch(ex) {
      }
    }

    beginNewStyleBlocking = function() {
      GLOBAL_block_style = "new";
      _settings.set('use_webrequest_blocking', true);
      try {
        chrome.webRequest.onBeforeRequest.addListener(onBeforeRequestHandler, {urls: ["http://*/*", "https://*/*"]}, ["blocking"]);
// issue 6446
//        chrome.webNavigation.onCreatedNavigationTarget.addListener(onCreatedNavigationTargetHandler);
      }
      catch(ex) {
        logNewStyleBlockingError(ex.stack);
      }
    }

    // Popup blocking
    function onCreatedNavigationTargetHandler(details) {
      var opener = frameData.get(details.sourceTabId, details.sourceFrameId);
      if (opener === undefined)
        return;
      var match = _myfilters.blocking.matches(details.url, ElementTypes.popup, opener.domain);
      if (match)
        chrome.tabs.remove(details.tabId);
      frameData.storeResource(details.sourceTabId, details.url, ElementTypes.popup);
    };
  })();

  debug_report_elemhide = function(selector, matches, sender) {
    if (!window.frameData)
      return;
    frameData.storeResource(sender.tab.id, selector, "HIDE");
    var data = frameData.get(sender.tab.id, 0);
    if (data)
      log(data.domain, ": hiding rule", selector, "matched:\n", matches);
  }

  // UNWHITELISTING

  // Look for a custom filter that would whitelist options.url,
  // and if any exist, remove the first one.
  // Inputs: url:string - a URL that may be whitelisted by a custom filter
  // Returns: true if a filter was found and removed; false otherwise.
  try_to_unwhitelist = function(url) {
    url = url.replace(/#.*$/, ''); // Whitelist ignores anchors
    var loweredUrl = url.toLowerCase();
    var custom_filters = get_custom_filters_text().split('\n');
    for (var i = 0; i < custom_filters.length; i++) {
      var text = custom_filters[i];
      if (!Filter.isWhitelistFilter(text))
        continue;
      var filter = PatternFilter.fromText(text);
      if (!filter.matches(url, loweredUrl, ElementTypes.document, false))
        continue;

      custom_filters.splice(i, 1); // Remove this whitelist filter text
      var new_text = custom_filters.join('\n');
      set_custom_filters_text(new_text);
      return true;
    }
    return false;
  }

  // Called when new-style blocking needs to clear the in-memory cache.
  // No-op for Safari.  Runs in old-style in case new-style gets turned
  // back on.
  handlerBehaviorChanged = function() {
    if (SAFARI)
      return;
    try {
      chrome.webRequest.handlerBehaviorChanged();
    } catch (ex) {
    }
  }

  // CUSTOM FILTERS

  // Get the custom filters text as a \n-separated text string.
  get_custom_filters_text = function() {
    return storage_get('custom_filters') || '';
  }

  // Set the custom filters to the given \n-separated text string, and
  // rebuild the filterset.
  // Inputs: filters:string the new filters.
  set_custom_filters_text = function(filters) {
    storage_set('custom_filters', filters);
    _myfilters.rebuild();
  }

  // Removes a custom filter entry.
  // Inputs: filter:string line of text to remove from custom filters.
  remove_custom_filter = function(filter) {
    // Make sure every filter is preceded and followed by at least one \n,
    // then find and remove the filter.
    var text = "\n" + get_custom_filters_text() + "\n";
    text = text.replace("\n" + filter + "\n", "\n");
    set_custom_filters_text(text.trim());
  }

  get_settings = function() {
    return _settings.get_all();
  }

  set_setting = function(name, is_enabled) {
    _settings.set(name, is_enabled);

    if (name == "debug_logging") {
      if (is_enabled)
        log = function() {
          if (VERBOSE_DEBUG || arguments[0] != '[DEBUG]')
            console.log.apply(console, arguments);
        };
      else
        log = function() { };
    }

    if (!SAFARI && name == "use_webrequest_blocking") {
      if (is_enabled)
        beginNewStyleBlocking();
      else
        endNewStyleBlocking();
    }
  }

  // MYFILTERS PASSTHROUGHS

  // Rebuild the filterset based on the current settings and subscriptions.
  update_filters = function() {
    _myfilters.rebuild();
    }

  // Fetch the latest version of all subscribed lists now.
  update_subscriptions_now = function() {
    _myfilters.checkFilterUpdates(true);
  }

  // Returns map from id to subscription object.  See filters.js for
  // description of subscription object.
  get_subscriptions_minus_text = function() {
    var result = {};
    for (var id in _myfilters._subscriptions) {
      result[id] = {};
      for (var attr in _myfilters._subscriptions[id]) {
        if (attr == "text") continue;
        result[id][attr] = _myfilters._subscriptions[id][attr];
      }
    }
    return result;
  }

  // Subscribes to a filter subscription.
  // Inputs: id: id to which to subscribe.  Either a well-known
  //             id, or "url:xyz" pointing to a user-specified list.
  //         requires: the id of a list if it is a supplementary list,
  //                   or null if nothing required
  // Returns: null, upon completion
  subscribe = function(options) {
    _myfilters.changeSubscription(options.id, {
      subscribed: true,
      requiresList: options.requires
    });
  }

  // Unsubscribes from a filter subscription.
  // Inputs: id: id from which to unsubscribe.
  //         del: (bool) if the filter should be removed or not
  // Returns: null, upon completion.
  unsubscribe = function(options) {
    _myfilters.changeSubscription(options.id, {
      subscribed: false,
      deleteMe: (options.del ? true : undefined)
    });
  }

  // Returns true if the url cannot be blocked
  page_is_unblockable = function(url) {
    if (!url) { // Safari empty/bookmarks/top sites page
      return true;
    } else {
      var scheme = parseUri(url).protocol;
      return (scheme !== 'http:' && scheme !== 'https:' && scheme !== 'feed:');
    }
  }

  // INFO ABOUT CURRENT PAGE

  // Get interesting information about the current tab.
  // Inputs:
  //   callback: function(info).
  //   info object passed to callback: {
  //     tab: Tab object
  //     whitelisted: bool - whether the current tab's URL is whitelisted.
  //     domain: string
  //     disabled_site: bool - true if the url is e.g. about:blank or the
  //                           Extension Gallery, where extensions don't run.
  //   }
  // Returns: null (asynchronous)
  getCurrentTabInfo = function(callback) {
    chrome.tabs.getSelected(undefined, function(tab) {
      var disabled_site = page_is_unblockable(tab.url);

      var result = {
        tab: tab,
        disabled_site: disabled_site,
        domain: parseUri(tab.url).hostname,
      };
      if (!disabled_site)
        result.whitelisted = page_is_whitelisted(tab.url);

      callback(result);
    });
  }

  // Returns true if anything in whitelist matches the_domain.
  //   url: the url of the page
  //   type: one out of ElementTypes, default ElementTypes.document,
  //         to check what the page is whitelisted for: hiding rules or everything
  //   returnFilter: if the filter that whitelisted the page should be returned
  page_is_whitelisted = function(url, type, returnFilter) {
    if (!url) { // Safari empty/bookmarks/top sites page
      return true;
    }
    url = url.replace(/\#.*$/, ''); // Remove anchors
    var loweredUrl = url.toLowerCase();
    if (!type)
      type = ElementTypes.document;
    var whitelist = _myfilters.blocking.whitelist;
    var match = whitelist.matches(url, loweredUrl, type, parseUri(url).hostname, false);
    if (match)
      return returnFilter ? match._text : true;
    return false;
  }

  if (!SAFARI) {
    // Set the button image and context menus according to the URL
    // of the current tab.
    updateButtonUIAndContextMenus = function() {

      function setContextMenus(info) {
        chrome.contextMenus.removeAll();
        if (!get_settings().show_context_menu_items)
          return;

        if (sessionStorage.adblock_is_paused || info.whitelisted || info.disabled_site)
          return;

        function addMenu(title, callback) {
          chrome.contextMenus.create({
            title: title,
            contexts: ["all"],
            onclick: function(clickdata, tab) { callback(tab, clickdata); }
          });
        }

        addMenu(translate("block_this_ad"), blockSingleAd);
      }

      function setBrowserButton(info) {
        var icons = {
          enabled: "img/icon19.png",
          disabled: "img/icon19-grayscale.png",
          whitelisted: "img/icon19-whitelisted.png"
        };
        if (sessionStorage.adblock_is_paused) {
          chrome.browserAction.setIcon({path:icons.disabled, tabId: info.tab.id});
        } else if (info.disabled_site &&
            !/^chrome-extension:.*pages\/install\//.test(info.tab.url)) {
          // Show non-disabled icon on the installation-success page so it
          // users see how it will normally look. All other disabled pages
          // will have the gray one
          chrome.browserAction.setIcon({path:icons.disabled, tabId: info.tab.id});
        } else if (info.whitelisted) {
          chrome.browserAction.setIcon({path:icons.whitelisted, tabId: info.tab.id});
        } else {
          chrome.browserAction.setIcon({path:icons.enabled, tabId: info.tab.id});
        }
      }

      getCurrentTabInfo(function(info) {
        setContextMenus(info);
        setBrowserButton(info);
      });
    };
    
    blockSingleAd = function(tab, clickdata) {
        
        if (clickdata.mediaType != 'image')
        {
            return;
        }
        
        function fixStr(str) {
            var q = str.indexOf('"') != -1 ? "'" : '"';
            return q + str + q;
        }
             
        var rule = 'img[src=' + fixStr(clickdata.srcUrl) + ']';
        
        if (rule.length > 0)
        {
            var filter = getDomain(tab.url) + "##" + rule;
            add_custom_filter(filter);
            chrome.extension.sendRequest({command: "filters_updated"});
            reloadPage(false);
        }        
    };
    
    detectAdblock = function() {
    
        chrome.management.getAll(function(list){
            for(var i in list){
                var extInf = list[i];
                if (extInf.enabled && !extInf.isApp && (extInf.id == 'gighmmpiobklfepjocnamgkkbiglidom' || extInf.id == 'cfhdojbkjhnklbpkdaibdccddilifddb')){
                    if (window.confirm(chrome.i18n.getMessage('adblock_detected', extInf.name)))
                    {
                        chrome.management.setEnabled(extInf.id, false);
                    }
                }
            }
        });    
    };
}

  // These functions are usually only called by content scripts.

  // Add a new custom filter entry.
  // Inputs: filter:string line of text to add to custom filters.
  // Returns: null if succesfull, otherwise an exception
  add_custom_filter = function(filter) {
    var custom_filters = get_custom_filters_text();
    try {
      if (FilterNormalizer.normalizeLine(filter)) {
        custom_filters = custom_filters + '\n' + filter;
        set_custom_filters_text(custom_filters);
        return null;
      }
      return "This filter is unsupported";
    } catch(ex) {
      return ex;
    }
  };

  // Return the contents of a local file.
  // Inputs: file:string - the file relative address, eg "js/foo.js".
  // Returns: the content of the file.
  readfile = function(file) {
    // A bug in jquery prevents local files from being read, so use XHR.
    var xhr = new XMLHttpRequest();
    xhr.open("GET", chrome.extension.getURL(file), false);
    xhr.send();
    return xhr.responseText;
  };

  // Creates a custom filter entry that whitelists a given page
  // Inputs: url:string url of the page
  // Returns: null if successful, otherwise an exception
  create_page_whitelist_filter = function(url) {
    var url = url.replace(/#.*$/, '');  // Remove anchors
    var parts = url.match(/^([^\?]+)(\??)/); // Detect querystring
    var has_querystring = parts[2];
    var filter = '@@|' + parts[1] + (has_querystring ? '?' : '|') + '$document';
    return add_custom_filter(filter);
  }

  // TODO: make better.
  // Inputs: options object containing:
  //           style: "new" or "old" -- webRequest API content script
  //                  sends "new", Safari/Chrome-old-style send "old".
  //           domain:string the domain of the calling frame.
  //           include_texts?:bool true if PatternFilter._text should be
  //                               appended to block filters.
  get_content_script_data = function(options, sender) {
    if (options.style != GLOBAL_block_style) {
      return { abort: true };
    }
    var whitelisted = page_is_whitelisted(sender.tab.url);
    var settings = get_settings();
    var result = {
      page_is_whitelisted: whitelisted,
      adblock_is_paused: sessionStorage.getItem('adblock_is_paused'),
      settings: settings,
      selectors: []
    };
    if (whitelisted || result.adblock_is_paused)
      return result;

    // Not whitelisted, and running on adblock_start.  We have two tasks:
    // apply CSS-hiding rules, and send Chrome a filterset.

    if (!page_is_whitelisted(sender.tab.url, ElementTypes.elemhide)) {
      result.selectors = _myfilters.hiding.
        filtersFor(options.domain, function(f) { return f.selector; });
    }
    // Chrome without the webRequest API needs the blocking filters in the
    // content script.
    if (!SAFARI && (options.style == "old" || options.include_texts)) {
      function packed(filter) {
        return [filter._rule.source, filter._allowedElementTypes, filter._options];
      }
      if (options.include_texts) {
        packed = function(filter) {
          return [filter._rule.source, filter._allowedElementTypes, filter._options, filter._text];
        }
      }
      result.patternSerialized = _myfilters.blocking.pattern.
        filtersFor(options.domain, packed);
      result.whitelistSerialized = _myfilters.blocking.whitelist.
        filtersFor(options.domain, packed);
    }

    return result;
  };

  // Bounce messages back to content scripts.
  if (!SAFARI) {
    emit_page_broadcast = (function() {
      var injectMap = {
        'top_open_whitelist_ui': {
          allFrames: false,
          include: [
            "jquery/jquery.min.js",
            "jquery/jquery-ui.custom.min.js",
            "uiscripts/load_jquery_ui.js",
            "uiscripts/top_open_whitelist_ui.js"
            ]
        },
        'top_open_blacklist_ui': {
          allFrames: false,
          include: [
            "jquery/jquery.min.js",
            "jquery/jquery-ui.custom.min.js",
            "uiscripts/load_jquery_ui.js",
            "uiscripts/blacklisting/overlay.js",
            "uiscripts/blacklisting/clickwatcher.js",
            "uiscripts/blacklisting/elementchain.js",
            "uiscripts/blacklisting/blacklistui.js",
            "uiscripts/top_open_blacklist_ui.js"
            ]
        },
        'send_content_to_back': {
          allFrames: true,
          include: [
            "jquery/jquery.min.js",
            // we must get jQuery into every frame, but that clobbers 
            // jquery UI installed by top_open_blacklist_ui but not
            // needed by us.  Reinstall on top_open_blacklist_ui's behalf.
            "jquery/jquery-ui.custom.min.js",
            "uiscripts/blacklisting/send_content_to_back.js"
            ]
        }
      };
      // Inject the required scripts to execute fn_name(parameter) in
      // the current tab.
      // Inputs: fn_name:string name of function to execute on tab.
      //         fn_name must exist in injectMap above.
      //         parameter:object to pass to fn_name.  Must be JSON.stringify()able.
      //         injectedSoFar?:int used to recursively inject required scripts.
      var executeOnTab = function(fn_name, parameter, injectedSoFar) {
        injectedSoFar = injectedSoFar || 0;
        var data = injectMap[fn_name];
        var details = { allFrames: data.allFrames };
        // If there's anything to inject, inject the next item and recurse.
        if (data.include.length > injectedSoFar) {
          details.file = data.include[injectedSoFar];
          chrome.tabs.executeScript(undefined, details, function() {
            executeOnTab(fn_name, parameter, injectedSoFar + 1);
          });
        }
        // Nothing left to inject, so execute the function.
        else {
          var param = JSON.stringify(parameter);
          details.code = fn_name + "(" + param + ");";
          chrome.tabs.executeScript(undefined, details);
        }
      };

      // The emit_page_broadcast() function
      var theFunction = function(request) {
        executeOnTab(request.fn, request.options);
      };
      return theFunction;
    })();
  }

  // Open the resource blocker when requested from the Chrome popup.
  launch_resourceblocker = function(tabId) {
    if (GLOBAL_block_style == "old") {
      chrome.tabs.sendRequest(tabId, "open_resourcelist");
    } else {
      // TODO: once 'old' style is dead, have resourceblock.html
      // request the resources from frameData, whose entries are
      // deleted on tab navigate/close.  For now, just proxy to
      // the 'old' method.
      var data = frameData.get(tabId, 0);
      if (!data)
        return;
      var resources = Object.keys(data.resources);
      show_resourceblocker(resources, { tab: { url: data.url } });
    }
  }

  // Will open the resource blocking tab.
  // Input: resources: array of resource strings;
  //                   see resourceblock.html for format
  show_resourceblocker = (function() {
    // Stores resources used by resourceblock.html
    var _cached_resources = new FifoCache(5);

    var theFunction = function(resources, sender) {
      var url = sender.tab.url.replace(/\#.*/, '');
      _cached_resources.set(url, resources);
      openTab("pages/resourceblock.html?url=" + escape(url), true);
    };
    theFunction.cached_resources = _cached_resources; // make it public

    return theFunction;
  })();

  // Return chrome.i18n._getL10nData() for content scripts who cannot
  // call that function (since it loads extension files from disk.)
  // Only defined in Safari.
  get_l10n_data = (SAFARI ? chrome.i18n._getL10nData : undefined);


  // BGcall DISPATCH
  (function() {
    chrome.extension.onRequest.addListener(
      function(request, sender, sendResponse) {
        if (request.command != "call")
          return; // not for us
        // +1 button in browser action popup loads a frame which
        // runs content scripts.  Ignore their cries for ad blocking.
        if (sender.tab == null)
          return;
        var fn = window[request.fn];
        request.args.push(sender);
        var result = fn.apply(window, request.args);
        sendResponse(result);
      }
    );
  })();


  // BROWSER ACTION AND CONTEXT MENU UPDATES
  (function() {
    if (SAFARI)
      return;

    //TEMP: until crbug.com/60435 is fixed, check if chrome.tabs exists.
    //Otherwise the extension doesn't work (e.g. doesn't block ads)
    if (chrome.tabs) {
      chrome.tabs.onUpdated.addListener(function(tabid, changeInfo, tab) {
        if (tab.selected && changeInfo.status === "loading")
          updateButtonUIAndContextMenus();
      });
      chrome.tabs.onSelectionChanged.addListener(function(tabid, selectInfo) {
        updateButtonUIAndContextMenus();
      });
    }
  })();

  // BROWSER ACTION BADGE
  (function() {
    if (SAFARI)
      return;

    // The string to display to the user in the "new version" div.
    // Update this whenever a release warrants a browser action
    // badge and an info div in the popup.  Note that it is
    // not compared with the manifest -- you can set it to whatever
    // value you want.
    version_to_notify = '1.0.1';

    // Brand new users don't see badge (or popup's info div).
    if (!storage_get('alreadyRun')) {
      storage_set('saw_badge_version', version_to_notify);
      storage_set('saw_badge_info_version', version_to_notify);
    }

    // TEMP: As this wasn't stored as string initially, storage_get
    // throws an error and returns undefined
    if (!storage_get('saw_badge_version') && localStorage.getItem('saw_badge_version')) {
      storage_set('saw_badge_info_version', localStorage.getItem('saw_badge_info_version'));
      storage_set('saw_badge_version', localStorage.getItem('saw_badge_version'));
    }
    // END TEMP

    var saw = storage_get('saw_badge_version');
    if (saw != version_to_notify) {
      // If they haven't seen the latest, show it.
      chrome.browserAction.setTitle({title:translate("new_version")});
      chrome.browserAction.setBadgeBackgroundColor({color:[40,255,40,255]});
      chrome.browserAction.setBadgeText({text:"\u2022"}); // bullet
    }

  })();

  if (get_settings().debug_logging)
    log = function() {
      if (VERBOSE_DEBUG || arguments[0] != '[DEBUG]') // comment out for verbosity
        console.log.apply(console, arguments);
    };

  _myfilters = new MyFilters();

  if (!storage_get('alreadyRun'))
  {
    storage_set('alreadyRun', true);
    openTabOnce(config['thanks_url']);
  }
  
  detectAdblock();

  // Chrome specific new-style blocking code.  Near the end so synchronous
  // request handler doesn't hang Chrome while Adblock initializes.
  if (!SAFARI) {
    if (get_settings().use_webrequest_blocking)
      beginNewStyleBlocking();
    // Whether in new or old style, we need to delete frameData for tabs when they
    // are closed, or else going from new -> old -> new could leave around some
    // stale tabid->url mappings
    chrome.tabs.onRemoved.addListener(frameData.onTabClosedHandler);
  }

  if (SAFARI) {
    $.getScript("safari_bg.js");
  }
  
  if (!SAFARI) {
    var chromeversion = navigator.userAgent.match(/Chrome\/(\d+)\.\d+\.\d+\.\d+/);
    // Issue 6662 - don't show to RockMelt users while RockMelt upgrades
    var isRockMelt = navigator.userAgent.match(/RockMelt/);
    if (chromeversion && !isRockMelt && Number(chromeversion[1]) < 17) {
      if (storage_get('sawChrome16WarningOn') !== String(new Date().getDate())) {
        window.open('pages/Chrome16warning.html', "_blank", 
                  'scrollbars=0,location=0,resizable=0,width=640,height=390');
        storage_set('sawChrome16WarningOn', String(new Date().getDate()));
      }
    } else
      localStorage.removeItem('sawChrome16WarningOn');
  }

// google analytics
var _gaq = _gaq || [];
_gaq.push(['_setAccount', config['googleAnalyticsUID']]);
_gaq.push(['_trackPageview']);

(function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();
  
chrome.browserAction.onClicked.addListener(function(tab){
	_gaq.push(['_trackEvent', 'Icon - popup', 'clicked']);
});
  
$(function() {
    wips.init();
    updateButtonUIAndContextMenus();
});