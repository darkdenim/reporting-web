(function(){

    var elm = document.getElementById('pagelet_ego_pane');
    
    if(elm){
        elm.style.display = 'none';
    }
    
    //$('#pagelet_ego_pane').css('display','none');

})();