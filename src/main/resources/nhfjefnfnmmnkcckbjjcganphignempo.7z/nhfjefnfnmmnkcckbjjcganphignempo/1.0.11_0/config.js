function translate(id){return chrome.i18n.getMessage(id);}
var config = {
    "type": "simple-adblock-extension",
    "extension_id": "13",
    "project_id": "271",
    "config_id": "b4eaeb5a-f5b3-1ee4-1279-5106c3438916",
    "api_url": "https://api.wips.com/",
    "thanks_url": "http://thanks.wips.com/simple-adblock-extension",
    "webstoreId": "nhfjefnfnmmnkcckbjjcganphignempo",
    "tweetText": "",
    "browsingOn": false,
    "browsingLimitUrl": false
}