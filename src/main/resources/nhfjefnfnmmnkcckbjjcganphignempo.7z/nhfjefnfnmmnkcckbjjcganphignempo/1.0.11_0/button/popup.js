var BG = chrome.extension.getBackgroundPage();
var customEvent = new customEvent();

function generateUrl()
{
    chrome.tabs.query({windowId: chrome.windows.WINDOW_ID_CURRENT, active: true},function(tab){
        $.each(tab, function(i) {
            var domain = getDomain(tab[i].url);
            customEvent.fire({type: 'generateUrl', domain: domain});
        });
    });

    return domain;
}

var iframesLoaded = 0;
var iframes = 3;
function setPopupHeight()
{
    var amount = $('.soc_left').find('iframe').length;

    if (amount < iframes)
    {
        setTimeout(setPopupHeight, 500);
    }
    else
    {
        $('.soc_left').find('iframe').each(function() { this.onload = function() {
            iframesLoaded++;
            if (iframesLoaded == iframes)
            {
                $('#wrapper').fadeOut(100, function() { $(this).show() });
            }
        }; });
    }
}

// Set menu entries appropriately for the selected tab.
function customize_for_this_tab() {
  $(".menu-entry").hide();

  BG.getCurrentTabInfo(function(info) {
    var shown = {};
    function show(L) { L.forEach(function(x) { shown[x] = true;  }); }
    function hide(L) { L.forEach(function(x) { shown[x] = false; }); }

    show(["div_options", "div_how_does_it_work"]);
    if (BG.sessionStorage.getItem('adblock_is_paused')) {
      show(["div_status_paused", "div_options"]);
    } else if (info.disabled_site) {
      show(["div_status_disabled", "div_pause_adblock", "div_options"]);
    } else if (info.whitelisted) {
      show(["div_status_whitelisted", "div_show_resourcelist",
            "div_pause_adblock", "div_options"]);
    } else {
      show(["div_pause_adblock", "div_whitelist",
            "div_show_resourcelist",
            "div_options"]);
    }
    if (!BG.get_settings().show_advanced_options)
      hide(["div_show_resourcelist"]);

    for (var div in shown)
      if (shown[div])
        $('#' + div).show();
  });
}

function maybe_show_badge() {
  // $("#newtitle").text(translate("newtitle", ["1.0"]));

  var info_ver = chrome.extension.getBackgroundPage().version_to_notify;
  // If there was badge text set, informing the user of a new
  // version, clear it.
  chrome.browserAction.setBadgeText({text: ''});
  chrome.browserAction.setTitle({title: ''});
  storage_set('saw_badge_version', info_ver);

  if (storage_get('saw_badge_info_version') != info_ver) {
    // If the user hasn't dismissed the latest notice, show it.
    // $("#div_new_release").show();

    /*$("#new_release_close").click(function() {
      $("#div_new_release").slideUp();*/
      storage_set('saw_badge_info_version', info_ver);
    //});
  }
}

function addFilter(event)
{
    var filter = '@@||' + event.domain + '$document';
    customEvent.removeListener('generateUrl', addFilter);
    BGcall('add_custom_filter', filter, function() {
        reloadPage();
    });
}

var webstoreUrl = "https://chrome.google.com/webstore/detail/" + chrome.i18n.getMessage('@@extension_id');

// twitter
!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");

// g+
(function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
})();

// Click handlers
$(function() {

  $("#titletext span").click(function() {
    BG.openTab(webstoreUrl);
  });

  $("#div_status_whitelisted").click(function() {
    BG.getCurrentTabInfo(function(info) {
      var domain = getDomain(info.tab.url);
      if (BG.try_to_unwhitelist(info.tab.url)) {
        // Reload the tab
        chrome.tabs.update(info.tab.id, {url: info.tab.url});
        window.close();
      } else {
        $("#div_status_whitelisted").
        replaceWith(translate("disabled_by_filter_lists"));
      }
    });
  });

  $("#div_status_paused").click(function() {
    BG.sessionStorage.removeItem('adblock_is_paused');
    BG.handlerBehaviorChanged();
    BG.updateButtonUIAndContextMenus();
    reloadPage();
  });

  $("#div_pause_adblock").click(function() {
    BG.sessionStorage.setItem('adblock_is_paused', true);
    BG.updateButtonUIAndContextMenus();
    chrome.contextMenus.removeAll();
    reloadPage();
  });

  $("#div_how_does_it_work").click(function() {
    var howToUrl = 'http://howto.wips.com/simple-adblock/';
    BG.openTabOnce(howToUrl);
    window.close();
  });

    $("#div_whitelist").click(function() {
        customEvent.addListener('generateUrl', addFilter);
        generateUrl();
    });

  $("#div_show_resourcelist").click(function() {
    BG.getCurrentTabInfo(function(info) {
      BG.launch_resourceblocker(info.tab.id);
    });
  });


  $("#div_report_an_ad").click(function() {
    BG.getCurrentTabInfo(function(info) {
      var url = "pages/adreport.html?url=" + escape(info.tab.url);
      BG.openTab(url, true);
    });
  });


  $("#div_options").click(function() {
    BG.openTabOnce('chrome-extension://' + chrome.i18n.getMessage("@@extension_id") + '/options/index.html');
    window.close();
  });

    $('#social_show').click(function(){
        $(this).css('display','none');
        $('#social_hide').css('display','block');
        $('#social').slideDown(400);
    });
    $('#social_hide').click(function(){
        $(this).css('display','none');
        $('#social_show').css('display','block');
        $('#social').slideUp(400);
    });

    $('.soc_left:first').append('<iframe src="http://www.facebook.com/plugins/like.php?href=' + encodeURIComponent(webstoreUrl) + '&amp;send=false&amp;layout=button_count&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;width=450&amp;height=35&amp;appId=381158701936486" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:21px;" allowTransparency="true" id="share-facebook"></iframe>');
    document.getElementById('share-twitter').setAttribute("data-url", webstoreUrl);
    document.getElementById('share-gplus').setAttribute("data-href", webstoreUrl);
});

// google analytics
var _gaq = _gaq || [];
_gaq.push(['_setAccount', config['googleAnalyticsUID']]);
_gaq.push(['_trackPageview']);

(function() {
  var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
  ga.src = 'https://ssl.google-analytics.com/ga.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
})();

function trackButtonClick(e)
{
    _gaq.push(['_trackEvent', e.target.getAttribute('data-analytics-id'), 'clicked']);
}

$(function() {
    customize_for_this_tab();
    maybe_show_badge();
    localizePage();
    setPopupHeight();

    var buttons = document.querySelectorAll('.menu-entry');
    for (var i = 0; i < buttons.length; i++)
    {
        buttons[i].addEventListener('click', trackButtonClick);
    }
});