package com.sniperfx.testbench.elements.components;

import com.vaadin.testbench.TestBenchElement;
import com.vaadin.testbench.elementsbase.Element;

@Element("order-editor")
public class OrderEditorElement extends TestBenchElement {

}
