package com.sniperfx.app.security;

import com.sniperfx.backend.data.entity.User;

@FunctionalInterface
public interface CurrentUser {

	User getUser();
}
